-- Script per la prima installazione e il mantenimento del full-text index search: 
-- Abilita il db per il full-text searching
-- Crea i cataloghi 'Segnalazioni' e 'Soluzioni'
-- Abilita la ricerca sulla colonna descrizione della tabella Segnalazioni e sulle colonne testo domanda e testo
-- risposta della tabella Soluzioni 
-- Start the Full population di entrambi i cataloghi
USE CRM 

-- Enable full-text searching in the database
EXEC sp_fulltext_database 'enable'
GO
-- Create a new full-text catalog
EXEC sp_fulltext_catalog 'Segnalazioni', 'create'
GO
EXEC sp_fulltext_catalog 'Soluzioni', 'create'
GO
-- Register the  table and column within it for full-text querying, then activate the table
BEGIN
DECLARE @pk_name VARCHAR(80)
SELECT @pk_name = name 
	from sysindexes 
	WHERE id = (select id from dbo.sysobjects where id = object_id(N'[dbo].[SEGNALAZIONI]'))AND indid = 1
	
EXEC sp_fulltext_table 
			'SEGNALAZIONI',			
		 	'create', 
		 	'Segnalazioni',
		 	@pk_name
EXEC sp_fulltext_column 'SEGNALAZIONI',
			'DESCRISEGNAL',
			'add'
			,0x0410
EXEC sp_fulltext_table  'SEGNALAZIONI',
			'activate'

SELECT @pk_name = name 
	from sysindexes 
	WHERE id = (select id from dbo.sysobjects where id = object_id(N'[dbo].[SOLUZIONI]')) AND indid = 1 

EXEC sp_fulltext_table 
			'SOLUZIONI',			
		 	'create', 
		 	'Soluzioni',
		 	@pk_name
EXEC sp_fulltext_column 'SOLUZIONI',
			'TESTDOMASOLU',
			'add'
			,0x0410
EXEC sp_fulltext_column 'SOLUZIONI',
			'TESTRISPSOLU',
			'add'
			,0x0410			
EXEC sp_fulltext_table  'SEGNALAZIONI',
			'activate'
END 

-- Start full population
EXEC sp_fulltext_catalog 'Segnalazioni',
			'start_full'
WHILE (SELECT fulltextcatalogproperty ('Segnalazioni','populatestatus')) <> 0
	BEGIN
		WAITFOR DELAY '00:00:02'
	CONTINUE
END
GO
EXEC sp_fulltext_catalog 'Soluzioni',
			'start_full'
WHILE (SELECT fulltextcatalogproperty ('Soluzioni','populatestatus')) <> 0
	BEGIN
		WAITFOR DELAY '00:00:02'
	CONTINUE
END
GO